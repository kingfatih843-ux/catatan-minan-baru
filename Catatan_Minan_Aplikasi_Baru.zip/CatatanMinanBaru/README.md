# Catatan Minan — Aplikasi baru

Aplikasi Android sederhana untuk catatan transaksi mingguan dan data rekening driver.

## Fitur
- Catatan transaksi: tanggal, dari, ke/nama driver, UJ, Borongan, dan Sisa otomatis (Borongan dikurangi UJ).
- Total UJ, Borongan, Sisa, dan jumlah transaksi per periode.
- Data driver: nama driver, nama bank, nomor rekening, dan atas nama.
- Tambah data lewat tombol di bagian bawah; tekan lama baris untuk edit atau hapus.
- Data disimpan lokal di SQLite pada HP.
- Bagikan laporan sebagai satu gambar PNG melalui menu berbagi Android, termasuk transaksi, total, dan data rekening.
- Nomor kendaraan dan periode dapat diubah.

## Build APK melalui GitHub Actions
1. Buat repository GitHub baru, misalnya `catatan-minan-baru`.
2. Ekstrak ZIP ini di HP, lalu unggah **isi folder proyek** ke root repository (folder `.github` harus ikut terunggah).
3. Buka tab **Actions** dan pilih **Build Catatan Minan APK**.
4. Setelah selesai dengan tanda centang hijau, buka hasil workflow dan unduh artifact **Catatan-Minan-APK**.
5. Ekstrak artifact ZIP dan pasang `app-debug.apk` di Android.

Catatan: aplikasi ini memakai applicationId baru `com.minan.catatan`, sehingga akan terpasang sebagai aplikasi terpisah dari aplikasi lama. Data dimulai kosong. Build perlu dijalankan di GitHub Actions; APK belum dibangun atau diuji di perangkat pada saat proyek ini disiapkan.

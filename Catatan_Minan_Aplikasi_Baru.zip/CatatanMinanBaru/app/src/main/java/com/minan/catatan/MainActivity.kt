package com.minan.catatan

import android.app.*
import android.content.*
import android.database.sqlite.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

private const val NAVY = 0xFF193253.toInt()
private const val GOLD = 0xFFD9AA4D.toInt()
private const val PALE = 0xFFEAF0F8.toInt()
private const val INK = 0xFF263447.toInt()

class Db(context: Context) : SQLiteOpenHelper(context, "catatan_minnan.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, week TEXT, date TEXT, from_place TEXT, to_driver TEXT, uj INTEGER, borongan INTEGER)")
        db.execSQL("CREATE TABLE drivers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, bank TEXT, account TEXT, owner TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun transactions(week: String): List<Tx> {
        val out = mutableListOf<Tx>(); readableDatabase.rawQuery("SELECT id,date,from_place,to_driver,uj,borongan FROM transactions WHERE week=? ORDER BY id", arrayOf(week)).use { c ->
            while (c.moveToNext()) out.add(Tx(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getInt(5)))
        }; return out
    }
    fun drivers(): List<Driver> {
        val out = mutableListOf<Driver>(); readableDatabase.rawQuery("SELECT id,name,bank,account,owner FROM drivers ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out.add(Driver(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4)))
        }; return out
    }
    fun saveTx(id: Long?, week: String, date: String, from: String, to: String, uj: Int, borongan: Int) {
        val v = android.content.ContentValues().apply { put("week", week); put("date", date); put("from_place", from); put("to_driver", to); put("uj", uj); put("borongan", borongan) }
        if (id == null) writableDatabase.insert("transactions", null, v) else writableDatabase.update("transactions", v, "id=?", arrayOf(id.toString()))
    }
    fun saveDriver(id: Long?, name: String, bank: String, account: String, owner: String) {
        val v = android.content.ContentValues().apply { put("name", name); put("bank", bank); put("account", account); put("owner", owner) }
        if (id == null) writableDatabase.insert("drivers", null, v) else writableDatabase.update("drivers", v, "id=?", arrayOf(id.toString()))
    }
    fun delete(table: String, id: Long) { writableDatabase.delete(table, "id=?", arrayOf(id.toString())) }
}
data class Tx(val id: Long, val date: String, val from: String, val to: String, val uj: Int, val borongan: Int) { val sisa get() = borongan - uj }
data class Driver(val id: Long, val name: String, val bank: String, val account: String, val owner: String)

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var body: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var plate: EditText
    private lateinit var period: EditText
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val nf = NumberFormat.getNumberInstance(Locale("id", "ID"))
    private var week = "09/11 - 15/11"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        week = prefs.getString("week", "09/11 - 15/11") ?: "09/11 - 15/11"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF5F7FA.toInt()) }
        scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(16)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(0xFFFFFFFF.toInt()) }
        actions.addView(button("+ Transaksi", NAVY) { saveSettings(); txDialog(null) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        actions.addView(button("+ Driver", GOLD) { driverDialog(null) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        root.addView(actions)
        setContentView(root)
        render()
    }

    private fun render() {
        body.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background(NAVY, 16) }
        header.addView(label("CATATAN MINAN", 27, 0xFFFFFFFF.toInt(), true))
        plate = EditText(this).apply { setText(prefs.getString("plate", "B 9334 FXU")); setTextColor(0xFFFFCC66.toInt()); textSize = 19f; setSingleLine(); setBackgroundColor(android.graphics.Color.TRANSPARENT); setPadding(0, dp(3), 0, dp(3)); hint = "Nomor kendaraan"; hintTextColor = 0xFFB8C5D5.toInt() }
        header.addView(plate)
        period = EditText(this).apply { setText(week); setTextColor(0xFFFFFFFF.toInt()); textSize = 16f; setSingleLine(); setBackgroundColor(android.graphics.Color.TRANSPARENT); setPadding(0, dp(3), 0, 0); hint = "Periode, contoh 09/11 - 15/11"; hintTextColor = 0xFFB8C5D5.toInt() }
        header.addView(period)
        body.addView(header, match().apply { bottomMargin = dp(12) })
        body.addView(sectionTitle("CATATAN TRANSAKSI"))
        val txs = db.transactions(week)
        body.addView(transactionTable(txs))
        val totalUj = txs.sumOf { it.uj }; val totalBor = txs.sumOf { it.borongan }; val totalSisa = txs.sumOf { it.sisa }
        val totals = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); background(PALE, 0) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(label("TOTAL", 16, NAVY, true), LinearLayout.LayoutParams(0, -2, .8f))
        row.addView(label("UJ: ${fmt(totalUj)}", 15, NAVY, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label("Borongan: ${fmt(totalBor)}", 15, NAVY, true), LinearLayout.LayoutParams(0, -2, 1.4f))
        row.addView(label("Sisa: ${fmt(totalSisa)}", 15, NAVY, true), LinearLayout.LayoutParams(0, -2, .9f))
        totals.addView(row); totals.addView(label("Jumlah transaksi: ${txs.size}", 13, 0xFF69788B.toInt(), false))
        body.addView(totals, match())
        body.addView(space(12))
        body.addView(sectionTitle("DATA REKENING DRIVER"))
        body.addView(driverTable(db.drivers()))
        body.addView(space(12))
        val share = button("Bagikan laporan lengkap ke WhatsApp", 0xFF159957.toInt()) { saveSettings(); shareReport() }
        body.addView(share, match().apply { height = dp(50) })
        body.addView(space(8))
        body.addView(button("Simpan nomor kendaraan & periode", NAVY) { saveSettings(); render(); toast("Pengaturan disimpan") }, match().apply { height = dp(46) })
    }

    private fun transactionTable(txs: List<Tx>): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background(0xFFFFFFFF.toInt(), 8) }
        val headers = listOf("Tanggal", "Dari", "Ke", "UJ", "Borongan", "Sisa")
        val widths = floatArrayOf(1.1f, .9f, 1.2f, .65f, 1f, .7f)
        outer.addView(tableRow(headers, widths, true))
        txs.forEachIndexed { i, t ->
            val cells = listOf(t.date, t.from, t.to, fmt(t.uj), fmt(t.borongan), fmt(t.sisa))
            val r = tableRow(cells, widths, false); r.setBackgroundColor(if (i % 2 == 0) 0xFFF4F7FB.toInt() else 0xFFFFFFFF.toInt())
            r.setOnLongClickListener { txDialog(t); true }; outer.addView(r)
        }
        if (txs.isEmpty()) outer.addView(label("Belum ada transaksi. Tekan + Transaksi untuk menambahkan.", 13, 0xFF69788B.toInt(), false).apply { setPadding(dp(12), dp(18), dp(12), dp(18)) })
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = true; addView(outer); setBackgroundColor(0xFFFFFFFF.toInt()) }
    }

    private fun driverTable(drivers: List<Driver>): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background(0xFFFFFFFF.toInt(), 8) }
        val widths = floatArrayOf(1.05f, .8f, 1.25f, 1.05f)
        outer.addView(tableRow(listOf("Nama Driver", "Nama Bank", "Nomor Rekening", "Atas Nama"), widths, true))
        drivers.forEachIndexed { i, d ->
            val r = tableRow(listOf(d.name, d.bank, d.account, d.owner), widths, false)
            r.setBackgroundColor(if (i % 2 == 0) 0xFFF4F7FB.toInt() else 0xFFFFFFFF.toInt())
            r.setOnLongClickListener { driverDialog(d); true }; outer.addView(r)
        }
        if (drivers.isEmpty()) outer.addView(label("Belum ada data driver. Tekan + Driver untuk menambahkan.", 13, 0xFF69788B.toInt(), false).apply { setPadding(dp(12), dp(18), dp(12), dp(18)) })
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = true; addView(outer); setBackgroundColor(0xFFFFFFFF.toInt()) }
    }

    private fun tableRow(values: List<String>, weights: FloatArray, head: Boolean): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(if (head) GOLD else 0xFFFFFFFF.toInt()) }
        values.forEachIndexed { i, value ->
            val cell = TextView(this).apply { text = value; textSize = if (head) 13f else 14f; setTextColor(if (head) NAVY else INK); if (head || i >= 3) setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12)); minWidth = dp(if (head) 88 else 76) }
            row.addView(cell, LinearLayout.LayoutParams(0, -2, weights[i]))
        }
        return row
    }

    private fun txDialog(old: Tx?) {
        val fields = listOf("Tanggal (contoh Sen, 09/11)", "Dari", "Ke / Nama Driver", "UJ", "Borongan")
        val inputs = fields.map { EditText(this).apply { hint = it; setSingleLine(); textSize = 16f } }
        old?.let { inputs[0].setText(it.date); inputs[1].setText(it.from); inputs[2].setText(it.to); inputs[3].setText(it.uj.toString()); inputs[4].setText(it.borongan.toString()) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), 0) }; inputs.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle(if (old == null) "Tambah Transaksi" else "Edit Transaksi").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                try { if (inputs.take(3).any { it.text.isBlank() }) throw Exception("Lengkapi tanggal, dari, dan driver")
                    db.saveTx(old?.id, week, inputs[0].text.toString(), inputs[1].text.toString(), inputs[2].text.toString(), inputs[3].text.toString().toInt(), inputs[4].text.toString().toInt()); render()
                } catch (_: Exception) { toast("Isi UJ dan Borongan dengan angka. Pastikan kolom wajib terisi.") }
            }.apply { if (old != null) setNeutralButton("Hapus") { _, _ -> db.delete("transactions", old.id); render() } }
            .setNegativeButton("Batal", null).show()
    }

    private fun driverDialog(old: Driver?) {
        val fields = listOf("Nama Driver", "Nama Bank", "Nomor Rekening", "Atas Nama")
        val inputs = fields.map { EditText(this).apply { hint = it; setSingleLine(); textSize = 16f } }
        old?.let { inputs[0].setText(it.name); inputs[1].setText(it.bank); inputs[2].setText(it.account); inputs[3].setText(it.owner) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), 0) }; inputs.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle(if (old == null) "Tambah Driver" else "Edit Data Driver").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                if (inputs.any { it.text.isBlank() }) toast("Semua kolom harus diisi") else { db.saveDriver(old?.id, inputs[0].text.toString(), inputs[1].text.toString(), inputs[2].text.toString(), inputs[3].text.toString()); render() }
            }.apply { if (old != null) setNeutralButton("Hapus") { _, _ -> db.delete("drivers", old.id); render() } }
            .setNegativeButton("Batal", null).show()
    }

    private fun saveSettings() {
        week = period.text.toString().ifBlank { "Periode belum diisi" }
        prefs.edit().putString("week", week).putString("plate", plate.text.toString()).apply()
    }

    private fun shareReport() {
        try {
            saveSettings(); render()
            body.measure(View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels - dp(24), View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            body.layout(0, 0, body.measuredWidth, body.measuredHeight)
            val bitmap = Bitmap.createBitmap(body.measuredWidth.coerceAtLeast(1), body.measuredHeight.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap); canvas.drawColor(0xFFF5F7FA.toInt()); body.draw(canvas)
            val file = File(cacheDir, "laporan_catatan_minnan.png"); FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply { type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_TEXT, "Laporan Catatan Minan - ${plate.text}"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(intent, "Bagikan laporan"))
        } catch (e: Exception) { toast("Gagal membuat gambar laporan: ${e.message}") }
    }

    private fun sectionTitle(text: String) = TextView(this).apply { this.text = text; textSize = 15f; setTextColor(NAVY); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(4), dp(8), dp(4), dp(8)) }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(2), dp(3), dp(2), dp(3)) }
    private fun button(text: String, color: Int, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 14f; setTextColor(if (color == GOLD) NAVY else 0xFFFFFFFF.toInt()); background = GradientDrawable().apply { setColor(color); cornerRadius = dp(9).toFloat() }; setOnClickListener { click() } }
    private fun LinearLayout.background(color: Int, radius: Int) { background = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() } }
    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt(v: Int) = nf.format(v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
